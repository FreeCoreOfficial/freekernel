/* DEPRECATED: Use kernel/drivers/keyboard.cpp */
/* This file is intentionally left empty to avoid conflicts. */
