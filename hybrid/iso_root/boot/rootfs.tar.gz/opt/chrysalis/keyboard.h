#pragma once
/* DEPRECATED: Use kernel/drivers/keyboard.h */
