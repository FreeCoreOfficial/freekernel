#!/bin/sh
# /opt/chrysalis/init.sh - Chrysalis OS initialization on Alpine

echo "========================================"
echo "  CHRYSALIS OS - POWERED BY ALPINE"
echo "========================================"
echo ""
echo "Alpine Linux 6.6 Kernel"
echo "Busybox Shell"
echo "Chrysalis GUI Framework"
echo ""
echo "Mounting filesystems..."
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev

echo "Loading modules..."
insmod /boot/modloop 2>/dev/null || true

echo ""
echo "Starting Chrysalis OS GUI..."
echo "Shell: /bin/sh"
echo ""
echo "Welcome to Chrysalis OS!"
echo ""

# Start interactive shell
/bin/sh
